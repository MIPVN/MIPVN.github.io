---
name: Zhang Huijie  
position:  master student  
avatar: zhanghuijie.jpg  
joined: 2024  
title:Zhang Huijie
---


### Contact

<i class="fa fa-envelope-o"></i>  2635989569@qq.com<br>

<hr>

### Self-introduction

Hello, my name is Zhang Huijie, and I am an undergraduate student set to graduate from Beihang University in 2024. I'm also an incoming graduate student. Running is one of my hobbies, and I have secured the second place in the 800m race in Beijing. My research focuses on the field of Bird's Eye View (BEV) vision. Welcome everyone to actively engage in academic discussions with me！

### Research Interests

Multi-view Bird's Eye View (BEV)

